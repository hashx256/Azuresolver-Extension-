// Background service worker
// Intercepts network requests to definitively classify reCAPTCHA version.
//
// Key URL patterns:
//   /recaptcha/api2/anchor   → v2 widget iframe (checkbox or invisible)
//   /recaptcha/api2/bframe   → v2 challenge iframe
//   /recaptcha/api2/reload   → v3 token refresh (also v2, but combined with ?reason=q = v3)
//   /recaptcha/api2/userverify → v2 solve submission
//   /enterprise/...          → Enterprise endpoint (v2 or v3 based on sub-path)
//
// The ?k= param in these URLs IS the sitekey.

// Priority table — mirrors content.js / injected.js
// NOTE: Enterprise v3 from reload?reason=q is given priority 8 (above v2 anchor at 7)
// so that if an Enterprise site fires both (unlikely but possible), v3 wins.
const TYPE_PRIORITY = {
  'reCAPTCHA Enterprise v3': 8,  // reload?reason=q is definitively v3
  'reCAPTCHA Enterprise v2': 7,  // anchor/bframe is definitively v2
  'reCAPTCHA Enterprise':    6,
  'reCAPTCHA v3':            5,
  'reCAPTCHA v2 Invisible':  4,
  'reCAPTCHA v2 Explicit':   3,
  'reCAPTCHA v2 Checkbox':   2,
  'hCaptcha':                9,
  'Cloudflare Turnstile':    9,
};
function prio(type) { return TYPE_PRIORITY[type] ?? 1; }

function mergeAndSave(tabId, type, sitekey) {
  if (!sitekey || sitekey.length < 10 || tabId < 0) return;
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    const pageUrl = tab.url;
    chrome.storage.local.get('captchaData', ({ captchaData }) => {
      const existing = (captchaData && captchaData.url === pageUrl)
        ? captchaData
        : { url: pageUrl, captchas: [], ts: Date.now() };

      const match = existing.captchas.find(c => c.sitekey === sitekey);
      if (match) {
        // Upgrade if we now have a more confident type
        if (prio(type) > prio(match.type)) {
          match.type = type;
          existing.ts = Date.now();
          chrome.storage.local.set({ captchaData: existing });
        }
        return;
      }
      existing.captchas.push({ type, sitekey });
      existing.url = pageUrl;
      existing.ts = Date.now();
      chrome.storage.local.set({ captchaData: existing });
    });
  });
}

// Classify a reCAPTCHA request URL into the correct type.
// Returns { type, sitekey } or null.
function classifyRecaptchaUrl(url) {
  const isEnterprise = url.includes('/recaptcha/enterprise');

  // Extract sitekey from ?k= param
  const km = url.match(/[?&]k=([A-Za-z0-9_\-]{20,})/);
  if (!km || km[1].startsWith('0x')) return null;
  const sitekey = km[1];

  // ── Path-based classification (most reliable) ──────────────────────────
  // /anchor  → v2 widget load. Anchor frame ONLY exists for v2.
  // Enterprise v3 sites (Netflix, Ticketmaster) NEVER fire /anchor — they
  // only hit /enterprise/reload?reason=q. So /enterprise/anchor = Enterprise v2.
  // Priority for Enterprise v2 anchor (7) < Enterprise v3 reload (8), so if
  // injected.js already marked it as Enterprise v3, this won't downgrade it.
  if (url.includes('/anchor')) {
    const sizem = url.match(/[?&]size=([^&]+)/);
    const size = sizem ? sizem[1].toLowerCase() : '';
    if (isEnterprise) {
      return { type: 'reCAPTCHA Enterprise v2', sitekey };
    }
    return { type: size === 'invisible' ? 'reCAPTCHA v2 Invisible' : 'reCAPTCHA v2 Checkbox', sitekey };
  }

  // /bframe  → v2 image/audio challenge frame (only v2 has these)
  if (url.includes('/bframe') || url.includes('/userverify')) {
    return { type: isEnterprise ? 'reCAPTCHA Enterprise v2' : 'reCAPTCHA v2 Checkbox', sitekey };
  }

  // /reload  → token refresh. Both v2 and v3 use this, but:
  //   ?reason=q  → v3 background score request
  //   ?reason=fi → v2 image challenge load
  //   ?reason=t  → v2 audio challenge
  //   ?reason=r  → v2 token refresh after solve
  if (url.includes('/reload')) {
    const reasonm = url.match(/[?&]reason=([^&]+)/);
    const reason = reasonm ? reasonm[1] : '';
    if (reason === 'q') {
      return { type: isEnterprise ? 'reCAPTCHA Enterprise v3' : 'reCAPTCHA v3', sitekey };
    }
    if (reason === 'fi' || reason === 't' || reason === 'r') {
      return { type: isEnterprise ? 'reCAPTCHA Enterprise v2' : 'reCAPTCHA v2 Checkbox', sitekey };
    }
    // Unknown reason — use enterprise flag only, lower confidence
    return { type: isEnterprise ? 'reCAPTCHA Enterprise' : 'reCAPTCHA v2 Checkbox', sitekey };
  }

  // /api.js or other script requests with render= param
  const renderm = url.match(/[?&]render=([^&]+)/);
  if (renderm) {
    const val = renderm[1];
    if (val !== 'explicit' && val !== 'onload' && val.length >= 20) {
      return { type: isEnterprise ? 'reCAPTCHA Enterprise v3' : 'reCAPTCHA v3', sitekey: val };
    }
  }

  // Fallback — enterprise generic if we can't determine v2/v3
  if (isEnterprise) return { type: 'reCAPTCHA Enterprise', sitekey };

  // Last resort
  return { type: 'reCAPTCHA v2 Checkbox', sitekey };
}

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const url = details.url;
    const tabId = details.tabId;

    // ── Cloudflare Turnstile ───────────────────────────────────────────────
    if (url.includes('challenges.cloudflare.com')) {
      // PATH-based sitekey (most common): /cdn-cgi/.../0xSITEKEY/...
      const pathKeys = url.match(/\/(0x[A-Za-z0-9]{10,})/g);
      if (pathKeys) {
        pathKeys.forEach(m => mergeAndSave(tabId, 'Cloudflare Turnstile', m.slice(1)));
      }
      // Query param: ?k=0x...
      const qm = url.match(/[?&]k=(0x[A-Za-z0-9]+)/);
      if (qm) mergeAndSave(tabId, 'Cloudflare Turnstile', qm[1]);
    }

    // ── reCAPTCHA (all endpoints) ─────────────────────────────────────────
    if (/google\.com\/recaptcha|recaptcha\.google\.com|recaptcha\.net\/recaptcha/.test(url)) {
      const result = classifyRecaptchaUrl(url);
      if (result) mergeAndSave(tabId, result.type, result.sitekey);
    }
  },
  {
    urls: [
      "https://challenges.cloudflare.com/*",
      "https://www.google.com/recaptcha/*",
      "https://recaptcha.google.com/*",
      "https://www.recaptcha.net/recaptcha/*"
    ]
  }
);

// Only clear when navigating to a genuinely different page (different origin+path)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    chrome.storage.local.get('captchaData', ({ captchaData }) => {
      if (!captchaData) return;
      try {
        const prev = new URL(captchaData.url || '');
        const next = new URL(changeInfo.url);
        if (prev.origin + prev.pathname !== next.origin + next.pathname) {
          chrome.storage.local.remove('captchaData');
        }
      } catch (_) { chrome.storage.local.remove('captchaData'); }
    });
  }
});
