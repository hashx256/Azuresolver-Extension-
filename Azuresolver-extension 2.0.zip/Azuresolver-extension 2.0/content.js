(() => {
  // ── Type priority (higher = more confident) ───────────────────────────────
  // First-wins deduplication is wrong for reCAPTCHA because a low-confidence
  // path (e.g. bare data-sitekey div → "v2 Checkbox") can fire before the
  // definitive signal (script render=SITEKEY → "v3"). We use upgrade-wins:
  // a new detection only replaces an existing one if it has strictly higher
  // priority, ensuring the best signal always wins regardless of scan order.
  const TYPE_PRIORITY = {
    'reCAPTCHA Enterprise v3': 8,  // reload?reason=q is the most definitive signal
    'reCAPTCHA Enterprise v2': 7,  // anchor/bframe definitive but below v3 reload
    'reCAPTCHA Enterprise':    6,   // enterprise confirmed but subtype unknown
    'reCAPTCHA v3':            5,
    'reCAPTCHA v2 Invisible':  4,
    'reCAPTCHA v2 Explicit':   3,
    'reCAPTCHA v2 Checkbox':   2,
    'hCaptcha':                8,   // fully deterministic, never downgrade
    'Cloudflare Turnstile':    8,
  };
  function priority(type) { return TYPE_PRIORITY[type] ?? 1; }

  const results = [];

  function pushUnique({ type, sitekey }) {
    if (!sitekey || sitekey.length < 10) return;
    const existing = results.find(r => r.sitekey === sitekey);
    if (existing) {
      // Upgrade to higher-priority type if we found a better signal
      if (priority(type) > priority(existing.type)) {
        existing.type = type;
        save();
      }
      return;
    }
    results.push({ type, sitekey });
    save();
  }

  function save() {
    chrome.storage.local.set({
      captchaData: { url: window.location.href, captchas: [...results], ts: Date.now() }
    });
  }

  function scanDOM() {
    // ── reCAPTCHA v2 — explicit .g-recaptcha divs ─────────────────────────
    // This is definitive v2: the widget div is only used by v2, never v3.
    document.querySelectorAll('.g-recaptcha').forEach(el => {
      const sitekey = el.getAttribute('data-sitekey');
      if (!sitekey) return;
      const size = (el.getAttribute('data-size') || '').toLowerCase();
      // Enterprise detection: /enterprise in any script src
      const entScript = document.querySelector('script[src*="/enterprise"]');
      const isEnterprise = !!entScript;
      let type = size === 'invisible' ? 'reCAPTCHA v2 Invisible' : 'reCAPTCHA v2 Checkbox';
      if (isEnterprise) type = 'reCAPTCHA Enterprise v2';
      pushUnique({ type, sitekey });
    });

    // ── Any data-sitekey element (non .g-recaptcha) ───────────────────────
    document.querySelectorAll('[data-sitekey]').forEach(el => {
      const sitekey = el.getAttribute('data-sitekey');
      if (!sitekey) return;
      if (sitekey.startsWith('0x')) {
        pushUnique({ type: 'Cloudflare Turnstile', sitekey });
      } else if (el.classList.contains('h-captcha') || el.closest('.h-captcha')) {
        pushUnique({ type: 'hCaptcha', sitekey });
      } else if (!el.classList.contains('g-recaptcha')) {
        // Unknown non-turnstile non-hcaptcha — tentatively v2 Checkbox, may be upgraded
        pushUnique({ type: 'reCAPTCHA v2 Checkbox', sitekey });
      }
    });

    // ── Cloudflare Turnstile divs ─────────────────────────────────────────
    document.querySelectorAll('.cf-turnstile, [class*="cf-turnstile"], [data-cf-turnstile-sitekey], [id*="cf-chl"]').forEach(el => {
      const sitekey = el.getAttribute('data-sitekey')
        || el.getAttribute('data-cf-turnstile-sitekey');
      if (sitekey) pushUnique({ type: 'Cloudflare Turnstile', sitekey });
    });

    document.querySelectorAll('[class*="turnstile"]').forEach(el => {
      const sitekey = el.getAttribute('data-sitekey');
      if (sitekey && sitekey.startsWith('0x')) pushUnique({ type: 'Cloudflare Turnstile', sitekey });
    });

    // ── reCAPTCHA iframes — anchor path tells us v2 vs v3 ────────────────
    // /api2/anchor  → v2 widget frame (checkbox or invisible)
    // /api2/bframe  → v2 challenge frame
    // /enterprise/  → Enterprise endpoint
    // v3 does NOT create anchor/bframe iframes — it only hits /reload
    document.querySelectorAll('iframe[src*="recaptcha"], iframe[src*="recaptcha.net"]').forEach(f => {
      const src = f.getAttribute('src') || '';
      const m = src.match(/[?&]k=([^&]+)/);
      if (!m) return;
      const sitekey = decodeURIComponent(m[1]);
      if (sitekey.startsWith('0x')) return;
      const isEnterprise = src.includes('/enterprise');
      if (isEnterprise) {
        // Enterprise iframe — check anchor for v2 vs v3
        const isV2 = src.includes('/anchor') || src.includes('/bframe');
        const size = (src.match(/[?&]size=([^&]+)/) || [])[1] || '';
        if (isV2) {
          pushUnique({ type: size === 'invisible' ? 'reCAPTCHA Enterprise v2' : 'reCAPTCHA Enterprise v2', sitekey });
        } else {
          pushUnique({ type: 'reCAPTCHA Enterprise', sitekey }); // may be upgraded later
        }
      } else {
        // Non-enterprise: anchor/bframe = v2 for sure
        const size = (src.match(/[?&]size=([^&]+)/) || [])[1] || '';
        pushUnique({ type: size === 'invisible' ? 'reCAPTCHA v2 Invisible' : 'reCAPTCHA v2 Checkbox', sitekey });
      }
    });

    // ── Turnstile iframes ─────────────────────────────────────────────────
    document.querySelectorAll('iframe[src*="challenges.cloudflare.com"]').forEach(f => {
      const src = f.getAttribute('src') || '';
      const qm = src.match(/[?&]k=(0x[A-Za-z0-9]+)/);
      if (qm) pushUnique({ type: 'Cloudflare Turnstile', sitekey: qm[1] });
      const pm = src.match(/\/(0x[A-Za-z0-9]{10,})/g);
      if (pm) pm.forEach(k => pushUnique({ type: 'Cloudflare Turnstile', sitekey: k.slice(1) }));
    });

    // ── reCAPTCHA script tags — definitive v3 signal when render=SITEKEY ──
    // render=SITEKEY in URL → v3 (enterprise or not)
    // render=explicit      → v2 loaded programmatically; sitekey found via DOM/globals
    // /enterprise in path  → Enterprise endpoint
    // Netflix/Ticketmaster: load enterprise.js with render=SITEKEY → Enterprise v3
    document.querySelectorAll('script[src*="recaptcha"]').forEach(s => {
      const src = s.getAttribute('src') || '';
      const isEnterprise = src.includes('/enterprise');
      const renderMatch = src.match(/[?&]render=([^&]+)/);

      if (renderMatch) {
        const val = decodeURIComponent(renderMatch[1]);
        if (val === 'explicit' || val === 'onload') {
          // render=explicit: v2 programmatic load OR enterprise v3 that calls execute() later.
          // Don't classify yet — injected.js intercepts will resolve it accurately.
          return;
        }
        if (!val.startsWith('0x') && val.length >= 20) {
          // render=SITEKEY is the definitive v3 signal — highest confidence
          pushUnique({ type: isEnterprise ? 'reCAPTCHA Enterprise v3' : 'reCAPTCHA v3', sitekey: val });
        }
      }
      // Enterprise script with no render param — wait for injected.js globals
    });

    // ── Turnstile script confirm — scan page for 0x keys ─────────────────
    document.querySelectorAll('script[src*="challenges.cloudflare.com/turnstile"]').forEach(() => {
      const allOx = document.documentElement.innerHTML.match(/\b(0x[A-Za-z0-9]{10,})\b/g);
      if (allOx) allOx.forEach(k => pushUnique({ type: 'Cloudflare Turnstile', sitekey: k }));
    });

    // ── hCaptcha ──────────────────────────────────────────────────────────
    document.querySelectorAll('.h-captcha').forEach(el => {
      const sitekey = el.getAttribute('data-sitekey');
      if (sitekey) pushUnique({ type: 'hCaptcha', sitekey });
    });
  }

  // MutationObserver — catches dynamically injected widgets
  const observer = new MutationObserver(() => scanDOM());
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-sitekey', 'class', 'src'] });
  setTimeout(() => observer.disconnect(), 20000);

  // Listen for injected.js results — NOT once:true because injected.js now
  // re-dispatches on every upgrade (e.g. when grecaptcha.enterprise.execute()
  // fires long after the initial scan — Netflix / Ticketmaster pattern).
  window.addEventListener('__captcha_injected_result', (e) => {
    (e.detail.found || []).forEach(item => pushUnique(item));
  });

  // Inject page-context script to access window vars
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('injected.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);

  // Initial scan + retries (catches lazy-loaded captchas)
  scanDOM();
  setTimeout(scanDOM, 800);
  setTimeout(scanDOM, 2000);
})();
