// ── Brand logo SVGs ───────────────────────────────────────────────────────────
const LOGO = {
  // Multi-color Google "G" — used for all reCAPTCHA variants
  google: `<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path fill="#4285F4" d="M43.6 20.5h-1.9V20H24v8h11.3c-1.6 4.6-6 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20c11 0 19.6-8 19.6-20 0-1.3-.1-2.3-.4-3.5z"/><path fill="#34A853" d="M6.3 14.7l6.6 4.8C14.6 16 18.9 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#FBBC05" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2c-2 1.4-4.5 2.3-7.2 2.3-5.3 0-9.7-3.4-11.3-8l-6.5 5C9.5 39.7 16.2 44 24 44z"/><path fill="#EA4335" d="M43.6 20.5h-1.9V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.6l6.2 5.2C40.9 36 44 30.5 44 24c0-1.3-.1-2.3-.4-3.5z"/></svg>`,
  // Cloudflare cloud (white on orange chip)
  cloudflare: `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="#fff" d="M16.5 13.2c.2-.6 0-1.1-.4-1.4-.4-.3-1-.5-1.7-.5l-7.6-.1c-.1 0-.2 0-.2-.1-.1-.1-.1-.2 0-.3.1-.2.2-.4.4-.5L9.7 9c2.3-1.1 5.3-.6 6.7 1.2.5.7.8 1.5.7 2.4 0 .2-.1.4-.1.6h-.5zm3.4-2.6c-.1 0-.3 0-.4.1-.1 0-.2.1-.2.2l-.3 1c-.2.6 0 1.1.4 1.4.4.3 1 .5 1.7.5l1.6.1c.1 0 .2 0 .2.1.1.1.1.2 0 .3-.1.2-.2.4-.4.5l-1.6.4c-.4.1-.6.4-.6.7 0 .3.2.6.6.7l3.3.1c2.6 0 4.6-2 4.6-4.4 0-2.3-1.9-4.2-4.4-4.2-.4 0-.8.1-1.2.2-.7-2.3-2.9-3.9-5.3-3.9-2.7 0-5 2.1-5.4 4.8 1.7-.5 3.7-.2 5.1.9.7-.6 1.5-.9 2.5-1z" transform="translate(-3 -1)"/></svg>`,
  // hCaptcha lowercase "h"
  hcaptcha: `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><text x="12" y="18" text-anchor="middle" font-family="Outfit, sans-serif" font-weight="900" font-size="18" fill="#fff">h</text></svg>`
};

function badgeLogo(kind) {
  if (kind === 'google')     return `<span class="badge-logo">${LOGO.google}</span>`;
  if (kind === 'cloudflare') return `<span class="badge-logo cf">${LOGO.cloudflare}</span>`;
  if (kind === 'hcaptcha')   return `<span class="badge-logo hc">${LOGO.hcaptcha}</span>`;
  return '';
}

// ── Type metadata ─────────────────────────────────────────────────────────────
const TYPE_META = {
  'reCAPTCHA v2 Checkbox': {
    cls:   'recaptcha-v2',
    logo:  'google',
    note:  '<strong>v2 Checkbox</strong> — The classic "I\'m not a robot" checkbox. Shown directly on the page. Requires user interaction unless risk score is low enough to auto-pass.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV2', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, isInvisible: false }
    })
  },
  'reCAPTCHA v2 Invisible': {
    cls:   'recaptcha-v2',
    logo:  'google',
    note:  '<strong>v2 Invisible</strong> — Hidden on page, triggered programmatically on form submit. No visible widget. Uses <code>data-size="invisible"</code> or JS API with invisible badge.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV2', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, isInvisible: true }
    })
  },
  'reCAPTCHA v2 Explicit': {
    cls:   'recaptcha-v2',
    logo:  'google',
    note:  '<strong>v2 Explicit</strong> — Rendered via JavaScript <code>grecaptcha.render()</code> after page load. Same solve method as checkbox.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV2', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, isInvisible: false }
    })
  },
  'reCAPTCHA v3': {
    cls:   'recaptcha-v3',
    logo:  'google',
    note:  '<strong>v3</strong> — No user interaction. Runs silently, returns a risk score 0.0–1.0. Requires <code>action</code> name (e.g. "submit", "login"). Higher <code>minScore</code> = more confident human.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV3', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, pageAction: 'submit', isInvisible: true }
    })
  },
  'reCAPTCHA Enterprise': {
    cls:   'enterprise',
    logo:  'google',
    note:  '<strong>Enterprise (subtype unknown)</strong> — Google\'s paid tier detected via the <code>/recaptcha/enterprise</code> endpoint. Subtype (v2/v3) could not be determined from available signals. If solve fails, try the Enterprise v2 or Enterprise v3 params explicitly.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV3Enterprise', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, pageAction: 'submit', isInvisible: true }
    })
  },
  'reCAPTCHA Enterprise v2': {
    cls:   'enterprise',
    logo:  'google',
    note:  '<strong>Enterprise v2</strong> — Google Enterprise tier using the v2 widget. Confirmed via <code>/recaptcha/enterprise/anchor</code> or <code>/bframe</code> network requests, or <code>grecaptcha.enterprise.render()</code> call. Use <code>ReCaptchaV2Enterprise</code> service.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV2Enterprise', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, isInvisible: false }
    })
  },
  'reCAPTCHA Enterprise v3': {
    cls:   'enterprise',
    logo:  'google',
    note:  '<strong>Enterprise v3</strong> — Google Enterprise tier using the v3 score-based API. Confirmed via <code>grecaptcha.enterprise.execute()</code> or <code>render=SITEKEY</code> on the enterprise endpoint. No user interaction required. Use <code>ReCaptchaV3Enterprise</code> service.',
    azure: (key, url) => ({
      info: { api_service: 'ReCaptchaV3Enterprise', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, pageAction: 'submit', isInvisible: true }
    })
  },
  'Cloudflare Turnstile': {
    cls:   'turnstile',
    logo:  'cloudflare',
    note:  '<strong>Cloudflare Turnstile</strong> — Sitekeys always start with <code>0x</code>. <code>cdata</code> and <code>action</code> are optional — remove them if the site does not require them.',
    azure: (key, url) => ({
      clientKey: 'AZURE-your-api-key',
      task: {
        type: 'turnstile',
        websiteURL: url,
        websiteKey: key,
        cdata: 'example_cdata',
        action: 'example_action'
      }
    })
  },
  'hCaptcha': {
    cls:   'hcaptcha',
    logo:  'hcaptcha',
    note:  '<strong>hCaptcha</strong> — Privacy-first CAPTCHA with image challenges. Used by Discord, Cloudflare, and many others. Has invisible and enterprise variants.',
    azure: (key, url) => ({
      info: { api_service: 'HCaptcha', api_token: 'AZURE-your-api-key' },
      params: { websiteURL: url, websiteKey: key, isInvisible: false }
    })
  }
};

function getMeta(type) {
  return TYPE_META[type] || {
    cls: 'recaptcha-v2',
    logo: 'google',
    note: 'Unknown CAPTCHA type.',
    azure: (key, url) => ({ clientKey: 'YOUR_API_KEY', task: { type: 'Unknown', websiteURL: url, websiteKey: key } })
  };
}

function truncate(str, n = 48) {
  return str.length > n ? str.slice(0, n) + '…' : str;
}

async function copyText(text, btn, label = 'Copy', doneLabel = '✓ Copied') {
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  const orig = btn.textContent;
  btn.textContent = doneLabel;
  btn.classList.add('ok');
  setTimeout(() => { btn.textContent = orig; btn.classList.remove('ok'); }, 1600);
}

// Render JSON with syntax highlighting
function syntaxHighlight(obj) {
  const json = JSON.stringify(obj, null, 2);
  return json
    .replace(/("(?:[^"\\]|\\.)*")(\s*:)/g, '<span class="key">$1</span>$2')
    .replace(/:\s*("(?:[^"\\]|\\.)*")/g, ': <span class="str">$1</span>')
    .replace(/:\s*(\d+\.?\d*)/g, ': <span class="num">$1</span>')
    .replace(/:\s*(true|false)/g, ': <span class="bool">$1</span>');
}

function buildCard(captcha, pageUrl, idx) {
  const meta = getMeta(captcha.type);
  const azureObj = meta.azure(captcha.sitekey, pageUrl);
  const azureJson = JSON.stringify(azureObj, null, 2);

  const card = document.createElement('div');
  card.className = `card ${meta.cls}`;
  card.style.animationDelay = `${idx * 80}ms`;

  card.innerHTML = `
    <div class="card-header">
      <span class="badge ${meta.cls}">
        ${badgeLogo(meta.logo)}
        ${captcha.type}
      </span>
      <div class="card-actions-top">
        <button class="copy-key-btn" title="Copy site key">Copy Key</button>
      </div>
    </div>

    <div class="field-label">Site Key</div>
    <div class="sitekey-box">${captcha.sitekey}</div>

    <div class="type-note">${meta.note}</div>

    <div class="meta-row">
      <div class="meta-box">
        <div class="field-label">Type</div>
        <div class="val">${captcha.type}</div>
      </div>
      <div class="meta-box">
        <div class="field-label">Page URL</div>
        <div class="val" title="${pageUrl}">${truncate(pageUrl, 26)}</div>
      </div>
    </div>

    <div class="azure-section">
      <div class="azure-header">
        <div class="azure-title">
          <span>⚡</span>
          <a href="https://azuresolver.com/docs" target="_blank">AzureSolver API Params</a>
          <span class="azure-link-icon">↗</span>
        </div>
        <button class="copy-params-btn">Copy JSON</button>
      </div>
      <div class="azure-params">${syntaxHighlight(azureObj)}</div>
    </div>
  `;

  // Copy site key
  card.querySelector('.copy-key-btn').addEventListener('click', function () {
    copyText(captcha.sitekey, this, 'Copy Key', '✓ Copied');
  });

  // Copy azure params
  card.querySelector('.copy-params-btn').addEventListener('click', function () {
    copyText(azureJson, this, 'Copy JSON', '✓ Done!');
  });

  return card;
}

function render(data) {
  const content    = document.getElementById('content');
  const urlEl      = document.getElementById('page-url');
  const foundCount = document.getElementById('found-count');
  const dot        = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const pill       = document.getElementById('count-pill');

  if (data && data.url) {
    urlEl.textContent = truncate(data.url, 54);
    urlEl.title = data.url;
  }

  content.innerHTML = '';

  if (!data || !data.captchas || data.captchas.length === 0) {
    content.innerHTML = `
      <div class="empty">
        <span class="empty-icon">🛡️</span>
        <h3>No CAPTCHAs detected</h3>
        <p>Navigate to a page that uses reCAPTCHA, Cloudflare Turnstile, or hCaptcha.<br>
        Then click ⟳ Rescan or reopen this panel.</p>
      </div>
    `;
    foundCount.textContent = 'No CAPTCHAs found';
    dot.classList.remove('active');
    statusText.textContent = 'idle';
    pill.textContent = '0';
    pill.classList.remove('has-results');
  } else {
    data.captchas.forEach((c, i) => content.appendChild(buildCard(c, data.url, i)));

    // Rescan button
    const rescan = document.createElement('button');
    rescan.className = 'rescan-btn';
    rescan.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
        <path d="M10.5 6A4.5 4.5 0 1 1 6 1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
        <path d="M6 1.5L8 3.5M6 1.5L8 0" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      Rescan Page
    `;
    rescan.addEventListener('click', triggerRescan);
    content.appendChild(rescan);

    const n = data.captchas.length;
    foundCount.textContent = `${n} CAPTCHA${n > 1 ? 's' : ''} detected`;
    dot.classList.add('active');
    statusText.textContent = 'active';
    pill.textContent = String(n);
    pill.classList.add('has-results');
  }
}

function triggerRescan() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="scanning">
      <div class="scan-ring"></div>
      <p>Rescanning page…</p>
    </div>
  `;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) return;
    chrome.storage.local.remove('captchaData', () => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ['content.js']
      }, () => {
        setTimeout(() => {
          chrome.storage.local.get('captchaData', ({ captchaData }) => render(captchaData));
        }, 700);
      });
    });
  });
}

// On popup open — run content.js then read storage
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  if (!tabs[0]) return;
  chrome.scripting.executeScript({
    target: { tabId: tabs[0].id },
    files: ['content.js']
  }, () => {
    // First check background's already-captured data (Turnstile via network)
    // then also check DOM scan results — use the freshest / most complete set
    setTimeout(() => {
      chrome.storage.local.get('captchaData', ({ captchaData }) => render(captchaData));
    }, 500);
  });
});
