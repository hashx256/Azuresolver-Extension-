(() => {
  // Runs in PAGE CONTEXT — has access to window globals.
  // Uses upgrade-wins priority; dispatches results immediately AND
  // re-dispatches after execute()/render() intercepts fire later.

  const TYPE_PRIORITY = {
    'reCAPTCHA Enterprise v3': 8,  // reload?reason=q / execute() intercept = most definitive
    'reCAPTCHA Enterprise v2': 7,  // anchor/bframe / render() intercept
    'reCAPTCHA Enterprise':    6,
    'reCAPTCHA v3':            5,
    'reCAPTCHA v2 Invisible':  4,
    'reCAPTCHA v2 Explicit':   3,
    'reCAPTCHA v2 Checkbox':   2,
    'hCaptcha':                8,
    'Cloudflare Turnstile':    8,
  };
  function prio(t) { return TYPE_PRIORITY[t] ?? 1; }

  const foundMap = new Map(); // sitekey → { type, sitekey }

  function push(type, sitekey) {
    if (!sitekey || typeof sitekey !== 'string') return;
    sitekey = sitekey.trim();
    if (sitekey.length < 10 || sitekey === 'explicit' || sitekey === 'onload') return;
    const existing = foundMap.get(sitekey);
    if (!existing || prio(type) > prio(existing.type)) {
      foundMap.set(sitekey, { type, sitekey });
      // Dispatch immediately on every upgrade so content.js gets the best type
      // even if execute() fires long after the initial dispatchEvent.
      dispatch();
    }
  }

  function dispatch() {
    window.dispatchEvent(new CustomEvent('__captcha_injected_result', {
      detail: { found: Array.from(foundMap.values()) }
    }));
  }

  // ── Cloudflare Turnstile intercept ────────────────────────────────────────
  try {
    let _ts = window.turnstile;
    function wrapTS(obj) {
      if (!obj || !obj.render) return obj;
      const orig = obj.render.bind(obj);
      obj.render = function (c, p) {
        try { if (p && p.sitekey) push('Cloudflare Turnstile', p.sitekey); } catch (_) {}
        return orig(c, p);
      };
      return obj;
    }
    if (_ts) wrapTS(_ts);
    Object.defineProperty(window, 'turnstile', {
      get() { return _ts; },
      set(v) { _ts = wrapTS(v); },
      configurable: true
    });
  } catch (_) {}

  // ── Cloudflare full-page challenge globals ────────────────────────────────
  try {
    const cf = window.__CF_chl_opt;
    if (cf) { const k = cf.cZone || cf.sitekey || cf.rRq; if (k) push('Cloudflare Turnstile', k); }
  } catch (_) {}
  try { const cf2 = window._cf_chl_opt; if (cf2 && cf2.cZone) push('Cloudflare Turnstile', cf2.cZone); } catch (_) {}
  try { if (window.__turnstile_sitekey) push('Cloudflare Turnstile', window.__turnstile_sitekey); } catch (_) {}

  // ── grecaptcha.enterprise intercept ──────────────────────────────────────
  // THIS is the key fix for Netflix / Ticketmaster:
  // They load enterprise.js with render=explicit, then call
  // grecaptcha.enterprise.execute(SITEKEY, {action}) later.
  // We wrap execute() and render() NOW so whenever they fire we catch it.
  function wrapGrecaptchaEnterprise(ent) {
    if (!ent || ent.__captcha_wrapped) return;
    ent.__captcha_wrapped = true;

    // execute(sitekey, {action}) → Enterprise v3
    if (typeof ent.execute === 'function') {
      const origExec = ent.execute.bind(ent);
      ent.execute = function (sitekey, opts) {
        try { push('reCAPTCHA Enterprise v3', sitekey); } catch (_) {}
        return origExec(sitekey, opts);
      };
    }

    // render(container, {sitekey, ...}) → Enterprise v2
    if (typeof ent.render === 'function') {
      const origRender = ent.render.bind(ent);
      ent.render = function (container, params) {
        try {
          const sk = (params && params.sitekey) ? params.sitekey
            : (typeof container === 'string' ? null : null);
          if (sk) push('reCAPTCHA Enterprise v2', sk);
        } catch (_) {}
        return origRender(container, params);
      };
    }
  }

  // Wrap non-enterprise grecaptcha execute (v3) and render (v2 explicit)
  function wrapGrecaptcha(gr) {
    if (!gr || gr.__captcha_wrapped) return;
    gr.__captcha_wrapped = true;

    if (typeof gr.execute === 'function' && !gr.enterprise) {
      const origExec = gr.execute.bind(gr);
      gr.execute = function (sitekey, opts) {
        try { push('reCAPTCHA v3', sitekey); } catch (_) {}
        return origExec(sitekey, opts);
      };
    }

    if (typeof gr.render === 'function') {
      const origRender = gr.render.bind(gr);
      gr.render = function (container, params) {
        try { if (params && params.sitekey) push('reCAPTCHA v2 Explicit', params.sitekey); } catch (_) {}
        return origRender(container, params);
      };
    }
  }

  // Intercept grecaptcha being SET on window (it may not exist yet)
  try {
    let _gr = window.grecaptcha;
    if (_gr) {
      wrapGrecaptcha(_gr);
      if (_gr.enterprise) wrapGrecaptchaEnterprise(_gr.enterprise);
    }
    Object.defineProperty(window, 'grecaptcha', {
      get() { return _gr; },
      set(v) {
        _gr = v;
        try {
          if (v) {
            wrapGrecaptcha(v);
            if (v.enterprise) wrapGrecaptchaEnterprise(v.enterprise);
          }
        } catch (_) {}
      },
      configurable: true
    });
    // Also watch for grecaptcha.enterprise being set after grecaptcha itself
    // (enterprise script sets window.grecaptcha.enterprise = {...} after load)
    if (_gr) {
      try {
        let _ent = _gr.enterprise;
        Object.defineProperty(_gr, 'enterprise', {
          get() { return _ent; },
          set(v) {
            _ent = v;
            try { if (v) wrapGrecaptchaEnterprise(v); } catch (_) {}
          },
          configurable: true
        });
      } catch (_) {}
    }
  } catch (_) {}

  // ── ___grecaptcha_cfg client walker ───────────────────────────────────────
  // Reads already-registered widget instances from the global config.
  //
  // CRITICAL v2 vs v3 Enterprise distinction:
  // In ___grecaptcha_cfg.clients, each widget is stored as a nested object.
  // The widget descriptor object contains:
  //
  //   v2 widget config keys (only present for v2):
  //     theme, size, tabindex, callback, 'expired-callback', 'error-callback',
  //     badge, s (the shadow DOM container), l (iframe element)
  //
  //   v3 config keys (only present for v3):
  //     action  ← set when execute() is called, may be absent if not yet called
  //
  //   BOTH have: sitekey
  //
  // The most reliable v2 signal is the presence of 'theme' or 'tabindex' or
  // an actual iframe/container DOM element reference in the descriptor.
  // The most reliable v3 signal from globals alone is the ABSENCE of widget
  // props — but that's ambiguous. So we also check:
  //   - whether the enterprise script has render=SITEKEY (v3) vs render=explicit (v2)
  //   - whether there is a .g-recaptcha DOM node (v2)
  //   - whether grecaptcha.enterprise.execute exists but .render was NOT called

  try {
    const cfg = window.___grecaptcha_cfg;
    const isEnterprise = !!(window.grecaptcha && window.grecaptcha.enterprise);

    if (cfg) {
      const clients = cfg.clients || {};

      Object.values(clients).forEach(client => {
        if (typeof client !== 'object' || client === null) return;

        // Walk all nested objects up to depth 4 looking for sitekey descriptors
        function walk(obj, depth) {
          if (depth > 4 || typeof obj !== 'object' || obj === null) return;
          for (const val of Object.values(obj)) {
            if (typeof val !== 'object' || val === null) continue;
            const sk = val.sitekey;
            if (typeof sk === 'string' && sk.length >= 10 && !sk.startsWith('0x')
                && sk !== 'explicit' && sk !== 'onload') {

              // ── Classify this descriptor ──────────────────────────────
              // v2 signals: widget appearance/behaviour config keys
              const v2Keys = ['theme', 'tabindex', 'badge', 'size'];
              const hasV2Config = v2Keys.some(k => k in val);
              // callback presence: v2 uses callback, v3 returns a Promise
              const hasCallback = typeof val.callback === 'function'
                || typeof val['expired-callback'] === 'function'
                || typeof val['error-callback'] === 'function';
              // DOM element references only exist in v2 widget descriptors
              const hasDomRef = (val.l instanceof Element) || (val.s instanceof Element)
                || (val.l instanceof HTMLIFrameElement);
              // v3 signal: action string (set at execute() call time)
              const hasAction = typeof val.action === 'string' && val.action.length > 0;

              const isV2Descriptor = hasV2Config || hasCallback || hasDomRef;
              const isV3Descriptor = hasAction && !isV2Descriptor;

              let type;
              if (isV3Descriptor) {
                type = isEnterprise ? 'reCAPTCHA Enterprise v3' : 'reCAPTCHA v3';
              } else if (isV2Descriptor) {
                const sz = (val.size || '').toLowerCase();
                type = isEnterprise
                  ? 'reCAPTCHA Enterprise v2'
                  : (sz === 'invisible' ? 'reCAPTCHA v2 Invisible' : 'reCAPTCHA v2 Checkbox');
              } else {
                // Ambiguous: no widget props, no action yet.
                // For Enterprise, lean v3 — Netflix/Ticketmaster pattern:
                // enterprise.js loaded with render=SITEKEY means v3.
                // We check the script tag to decide.
                const enterpriseScripts = document.querySelectorAll('script[src*="/enterprise"]');
                let scriptSaysV3 = false;
                enterpriseScripts.forEach(s => {
                  const m = (s.getAttribute('src') || '').match(/[?&]render=([^&]+)/);
                  if (m && m[1] !== 'explicit' && m[1] !== 'onload') scriptSaysV3 = true;
                });
                if (isEnterprise && scriptSaysV3) {
                  type = 'reCAPTCHA Enterprise v3';
                } else if (isEnterprise) {
                  // Enterprise loaded with render=explicit or no render param:
                  // could be v2 or v3 — mark generic, intercept will upgrade
                  type = 'reCAPTCHA Enterprise';
                } else {
                  type = 'reCAPTCHA v3'; // non-enterprise ambiguous → lean v3
                }
              }
              push(type, sk);
            }
            walk(val, depth + 1);
          }
        }
        walk(client, 0);
      });
    }
  } catch (_) {}

  // ── Inline script scan ────────────────────────────────────────────────────
  document.querySelectorAll('script:not([src])').forEach(s => {
    const text = s.textContent;
    if (!text) return;

    // Turnstile
    for (const m of text.matchAll(/\b(0x[A-Za-z0-9]{10,})\b/g))
      push('Cloudflare Turnstile', m[1]);
    for (const m of text.matchAll(/cZone\s*:\s*['"`]([^'"`]+)['"`]/g))
      push('Cloudflare Turnstile', m[1]);
    for (const m of text.matchAll(/turnstile\.render\s*\([^)]*sitekey['":\s]+['"]?(0x[A-Za-z0-9]{10,})['"]?/g))
      push('Cloudflare Turnstile', m[1]);

    // Enterprise v3: grecaptcha.enterprise.execute(SITEKEY, ...)
    for (const m of text.matchAll(/grecaptcha\.enterprise\.execute\s*\(\s*['"`]([A-Za-z0-9_\-]{20,})['"`]/g))
      push('reCAPTCHA Enterprise v3', m[1]);

    // Enterprise v2: grecaptcha.enterprise.render(container, {sitekey: SITEKEY})
    for (const m of text.matchAll(/grecaptcha\.enterprise\.render\s*\([^,)]*,\s*\{[^}]*sitekey\s*:\s*['"`]([A-Za-z0-9_\-]{20,})['"`]/g))
      push('reCAPTCHA Enterprise v2', m[1]);

    // v3: grecaptcha.execute(SITEKEY, ...) — negative lookbehind excludes .enterprise.
    for (const m of text.matchAll(/(?<!enterprise\.)grecaptcha\.execute\s*\(\s*['"`]([A-Za-z0-9_\-]{20,})['"`]/g))
      push('reCAPTCHA v3', m[1]);

    // v2 explicit render: grecaptcha.render(container, {sitekey: SITEKEY})
    for (const m of text.matchAll(/(?<!enterprise\.)grecaptcha\.render\s*\([^,)]+,\s*\{[^}]*sitekey\s*:\s*['"`]([A-Za-z0-9_\-]{20,})['"`]/g))
      push('reCAPTCHA v2 Explicit', m[1]);
  });

  // ── HTML scan — lowest priority fallback ──────────────────────────────────
  try {
    const html = document.documentElement.innerHTML;

    // Turnstile 0x keys
    for (const m of html.matchAll(/sitekey['"\\s:=]+['"\\s]?(0x[A-Za-z0-9]{10,})/gi))
      push('Cloudflare Turnstile', m[1]);

    // render=SITEKEY in any src string embedded in HTML
    for (const m of html.matchAll(/[?&]render=([A-Za-z0-9_\-]{20,})/g)) {
      const val = m[1];
      if (val === 'explicit' || val === 'onload') continue;
      if (val.startsWith('0x')) continue;
      const ctx = html.substring(Math.max(0, m.index - 120), m.index + 120);
      push(ctx.includes('/enterprise') ? 'reCAPTCHA Enterprise v3' : 'reCAPTCHA v3', val);
    }

    // Generic sitekey in JSON — absolute lowest priority
    for (const m of html.matchAll(/['"]sitekey['"]\s*:\s*['"]([A-Za-z0-9_\-]{20,})['"]/g)) {
      const key = m[1];
      if (key.startsWith('0x')) push('Cloudflare Turnstile', key);
      else push('reCAPTCHA v2 Checkbox', key); // lowest prio, will be upgraded
    }
  } catch (_) {}

  // Initial dispatch
  dispatch();
})();
